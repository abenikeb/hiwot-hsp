# Change Log

## [2.1.0] 2020-02-29
- refactor: all the product was changed and now it's the same version with PRO version and also the structure it's the same 

## [1.0.0] 2018-10-16
### Initial Release
